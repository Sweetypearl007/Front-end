module.exports = (req, res, next) => {
    console.log('testing request in middleware')
    const apiUrl = 'http://localhost:3030/users';
    let Axios = require("axios");
    if (req.method === 'POST' && req.path === '/users/authenticate') {
      Axios.get(apiUrl)
      .then(result => {
        let users = result.data
        let filteredUsers = users.filter(user => {
          return user.username === req.body.username && user.password === req.body.password;
        });
        if (filteredUsers.length) {
          let user = filteredUsers[0];
          let responseJson = {
              id: user.id,
              username: user.username,
              firstName: user.firstName,
              lastName: user.lastName,
          };
          res.status(200).json(responseJson)
        } else {
          res.status(400).json({message: 'wrong password'})
        }
      })
      .catch(err => {
        throw(err)
      });
    } else {
      next()
    }
  }