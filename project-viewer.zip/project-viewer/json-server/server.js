const jsonServer = require('json-server')
const server = jsonServer.create()
const router = jsonServer.router('db.json')
const middlewares = jsonServer.defaults()

server.use( jsonServer.bodyParser );
server.use(middlewares)
server.use(router)
server.use((req, res, next) => {
    if (req.method === 'POST' && req.path === '/users/authenticate') {
      let fs = require('fs')
      let jsonData = fs.readFile('./db.json', (err, data) => {
        return data
      })
      let users = JSON.parse(jsonData).users || []
      let filteredUsers = users.filter(user => {
        return user.username === req.body.username && user.password === req.body.password;
      });
      if (filteredUsers.length) {
        let user = filteredUsers[0];
        let responseJson = {
            id: user.id,
            username: user.username,
            firstName: user.firstName,
            lastName: user.lastName,
        };
        res.status(200).json(responseJson)
      } else {
        res.status(400).json({message: 'wrong password'})
      }
    } else {
      next()
    }
  })
server.listen(3030, () => {
  console.log('JSON Server is running')
})