import 'babel-polyfill';
import React from 'react';
import { Provider } from 'react-redux';
import { render } from 'react-dom';
import {browserHistory, Router} from 'react-router';
import routes from './routes';
// import * as projectActions from './actions/projectActions';
import './bootstrap/css/bootstrap.min.css';
import configureStore from './store/configureStore';

const store = configureStore();
// store.dispatch(projectActions);
render(
  <Provider store={store}>
    <Router history={browserHistory}>
        {routes}
    </Router> 
  </Provider>,
  document.getElementById('root')
);
// routes={routes}  />