const config = {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  }

export default config;