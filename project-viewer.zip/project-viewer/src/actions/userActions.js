import * as actionTypes from './actionTypes';
import Axios from 'axios';
import config from './configHeader';

const apiUrl = 'http://localhost:3030/users';
let querystring = require('querystring')

export const loginSuccess = (user) => {
    return {
        type: actionTypes.USERS_LOGIN_SUCCESS,
        user
    }    
}

export const loginRequest = (user) => { 
    return {
        type: actionTypes.USERS_LOGIN_REQUEST, 
        user 
    } 
}

export const loginFailure = (error) => { 
    return { 
        type: actionTypes.USERS_LOGIN_FAILURE, 
        error 
    } 
}

export const login = (username, password) => {
    return (dispatch) => {
        dispatch(loginRequest(username))
        dispatch(loginSuccess(false))
        dispatch(loginFailure(null))
        const data = {
            username: username,
            password: password
        }
        return Axios.post(
            apiUrl + '/authenticate', 
            querystring.stringify(data),
            config
        ).then(handleResponse)
        .then(responseData => {
            console.log('logged in')
            localStorage.setItem('user', JSON.stringify(responseData))
            window.location.reload(true)
            dispatch(loginSuccess(true))
        })
        .catch(error => {
            dispatch(loginFailure(error))
        })
    }
}

export const logoutSuccessful = (user) => {
    return {
        type: actionTypes.USERS_LOGOUT,
        user
    }
}

export const logout = () => {
    // remove user from local storage to log user out
    localStorage.removeItem('user');
    return (dispatch) => {
        dispatch(logoutSuccessful(false))
    }
}

export const registerSuccess = (user) =>{
    return {
        type: actionTypes.USERS_REGISTER_SUCCESS,
        user
    }
}

export const registerRequest = (user) =>{
    return {
        type: actionTypes.USERS_REGISTER_SUCCESS,
        user
    }
}

export const registerFailure = (error) =>{
    return {
        type: actionTypes.USERS_REGISTER_SUCCESS,
        error
    }
}

export const register = (user) => {
    return (dispatch) => {
        dispatch(registerRequest(user))
        dispatch(registerSuccess(false))
        dispatch(registerFailure(null))
        return Axios.post(apiUrl, user, config)
            .then(handleResponse)
            .then(response => {
                dispatch(registerSuccess(true))
            })
            .cathc(error => {
                dispatch(registerFailure(error))
            })
    }
}

export const handleResponse = (response) => {
    console.log({response})
    let data = response.data
    if (response.statusText !== "OK") {
        if (response.status === 401 || response.status === 400) {
            // auto logout if 401 response returned from api
            logout();
            window.location.reload(true);
        }
        const error = (data && data.message) || response.statusText;
        throw error;
    }
    return data;
}