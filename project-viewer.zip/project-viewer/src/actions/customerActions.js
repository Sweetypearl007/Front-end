import * as actionTypes from './actionTypes';
import Axios from 'axios';
import config from './configHeader';

const querystring = require('querystring')
const apiUrl = 'http://localhost:3030';

export const fetchCustomersSuccess = (customers) => {
  return {
    type: actionTypes.FETCH_CUSTOMERS_SUCCESS,
    customers
  }
};

export const createCustomerSuccess = (customer) => {
  return {
    type: actionTypes.CREATE_CUSTOMER_SUCCESS,
    customer
  }
};

export const fetchCustomerByIdSuccess = (customer) => {
  return {
    type: actionTypes.FETCH_CUSTOMER_BY_ID_SUCCESS,
    customer
  }
};

export const fetchCustomers = (projectId) => {
  return (dispatch) => {
    return Axios.get(apiUrl+'/projects/'+projectId+'/customers')
      .then(response => {
        dispatch(fetchCustomersSuccess(response.data))
      })
      .catch(error => {
        throw(error);
      });
  };
};

export const createCustomer = (customer) => {
  console.log(customer)
  return (dispatch) => {
    return Axios.post(apiUrl+'/projects/'+customer.projId+'/customers', querystring.stringify(customer), config)
      .then(response => {
        console.log(response.data)
        dispatch(createCustomerSuccess(response.data))
      })
      .catch(error => {
        throw(error);
      });
  };
};

export const fetchCustomerById = (projectId, customerId) => {
  console.log('fetching cus by id')
  return (dispatch) => {
    return Axios.get(apiUrl+'/projects/'+projectId+'/customers/'+customerId)
      .then(response => {
        dispatch(fetchCustomerByIdSuccess(response.data));
      })
      .catch(error => {
        throw(error);
      });
  };
};