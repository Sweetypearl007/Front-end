import * as actionTypes from './actionTypes';
import Axios from 'axios';
import config from './configHeader';

let querystring = require('querystring')

const apiUrl = 'http://localhost:3030/projects';

export const fetchProjectsSuccess = (projects) => {
  return {
    type: actionTypes.FETCH_PROJECTS_SUCCESS,
    projects
  }
};

export const createProjectSuccess = (project) => {
  return {
    type: actionTypes.CREATE_PROJECT_SUCCESS,
    project
  }
};

export const fetchProjectByIdSuccess = (project) => {
  return {
    type: actionTypes.FETCH_PROJECT_BY_ID_SUCCESS,
    project
  }
};

export const fetchProjects = () => {
  return (dispatch) => {
    return Axios.get(apiUrl)
      .then(response => {
        dispatch(fetchProjectsSuccess(response.data))
      })
      .catch(error => {
        throw(error);
      });
  };
};

export const createProject = (project) => {
  return (dispatch) => {
    return Axios.post(apiUrl, querystring.stringify(project), config)
      .then(response => {
        dispatch(createProjectSuccess(response.data))
      })
      .catch(error => {
        throw(error);
      });
  };
};

export const fetchProjectById = (projectId) => {
  console.log({projectId})
  return (dispatch) => {
    return Axios.get(apiUrl + '/' +projectId)
      .then(response => {
        console.log({projectId})
        console.log({respdata: response.data})
        dispatch(fetchProjectByIdSuccess(response.data));
      })
      .catch(error => {
        throw(error);
      });
  };
};