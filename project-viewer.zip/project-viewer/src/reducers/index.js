import { combineReducers } from 'redux';
import {projectReducer, projectsReducer} from './projectReducers'
import {customerReducer, customersReducer} from './customerReducers';
import {authentication} from './authenticationReducers'
import {registration} from './registrationReducers'

export default combineReducers({
  projects: projectsReducer,
  project: projectReducer,
  customers: customersReducer,
  customer: customerReducer,
  authentication,
  registration
});