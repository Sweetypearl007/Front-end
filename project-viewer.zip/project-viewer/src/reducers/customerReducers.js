export const customersReducer = (state = [], action) => {
    switch (action.type) {
      case 'CREATE_CUSTOMER_SUCCESS':
          return [
            ...state,
            Object.assign({}, action.customer)
          ];
      case 'FETCH_CUSTOMERS_SUCCESS':
            return action.customers;
      default:
            return state;
    }
  };
  
  export const customerReducer = (state = [], action) => {
    switch (action.type) {
      case 'FETCH_CUSTOMER_BY_ID_SUCCESS':
        return action.customer;
      default:
        return state;
    }
  };