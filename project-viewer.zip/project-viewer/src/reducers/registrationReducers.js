import * as actionTypes from '../actions/actionTypes'

export function registration(state = {}, action) {
  switch (action.type) {
    case actionTypes.USERS_REGISTER_REQUEST:
      return { registering: true };
    case actionTypes.USERS_REGISTER_SUCCESS:
      return {};
    case actionTypes.USERS_REGISTER_FAILURE:
      return {};
    default:
      return state
  }
}