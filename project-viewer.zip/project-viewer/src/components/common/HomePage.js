import React from 'react';
import ProjectsPage from '../project/ProjectsPage';
import LoginPage from './LoginPage';

const HomePage = () => {
    return localStorage.getItem('user') ? (<ProjectsPage/>) : (<LoginPage/>)
}

export default HomePage