import React, { Component } from 'react';
import './App.css';
import LoginPage from './common/LoginPage';

class App extends Component {
  render() {
    return (
      <LoginPage/>
    );
  }
}

export default App;
