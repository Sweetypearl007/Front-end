import React from 'react';
import { connect } from 'react-redux';
import CustomerForm from './CustomerForm';
import { Link } from 'react-router';
import * as customerActions from '../../actions/customerActions';

class CustomersPage extends React.Component{
  submitCustomer(input){
    const projId = this.props.params.proj_id
    this.props.createCustomer({...input, projId});
  }

  componentWillMount() {
    this.props.fetchCustomers(this.props.params.proj_id)
  }

  render(){
    return(
      <div className="row">
        <div className="col-md-6">
          <h3>Customers for project bearing ID: {this.props.params.proj_id}</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Email</th>
                <th>Address</th>
              </tr>
            </thead>
            <tbody>
            {this.props.customers.map((b, i) => {
              return(
                <tr key={i}>
                  <td>{b.name}</td>
                  <td>{b.contact}</td>
                  <td>{b.email}</td>
                  <td>{b.address}</td>
                  <td><Link to={`/customers/${b.id}`}>View</Link></td>
                </tr>
              )
            })}
            </tbody>
          </table>
        </div>
        <div className="col-md-6">
          <h3>New Customer</h3>
         <CustomerForm submitCustomer={this.submitCustomer.bind(this)} />
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    customers: state.customers
  }
};

const mapDispatchToProps = (dispatch) => {
  return {
    createCustomer: customer => dispatch(customerActions.createCustomer(customer)),
    fetchCustomers: (projId) => dispatch(customerActions.fetchCustomers(projId))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(CustomersPage);
