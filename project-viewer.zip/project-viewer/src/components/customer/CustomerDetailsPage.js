import React from 'react';
import {connect} from 'react-redux';
import CustomerDetails from './CustomerDetails'
import * as customerActions from '../../actions/customerActions';

class CustomerDetailsPage extends React.Component {
    componentWillMount(){
        console.log('reached cust details')
        const params = this.props.params
        this.props.fetchCustomerById(params.proj_id, params.cust_id);
    }

    render() {
        return (
            <div>
                <h1>Customer Details Page</h1>
                <CustomerDetails customer={this.props.customer}/>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
      customer: state.customer
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
      fetchCustomerById: (projectId, customerId) => dispatch(customerActions.fetchCustomerById(projectId, customerId)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(CustomerDetailsPage);
