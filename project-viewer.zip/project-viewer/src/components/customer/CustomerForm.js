import React from 'react';

const CustomerForm = (props) => {
    let nameInput, contactInput, emailInput, addressInput = null;
    return (
      <form onSubmit={e => {
            e.preventDefault();
            var input = {
              name: nameInput.value,
              contact: contactInput.value,
              email: emailInput.value,
              address: addressInput.value,
              id: '',
            };
            props.submitCustomer(input);
            e.target.reset();
          }}
            className="form-horizontal"
      >
        <div className="input-group">
          <label className="col-sm-2 control-label">Customer Name: </label>
          <div className="col-sm-10">
            <input
              type="text"
              name="name"
              ref={node => nameInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <label className="col-sm-2 control-label">Contact: </label>
          <div className="col-sm-10">
            <input
              type="text"
              name="contact"
              ref={node => contactInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <label className="col-sm-2 control-label">Email: </label>
          <div className="col-sm-10">
            <input
              type="text"
              name="email"
              ref={node => emailInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <label className="col-sm-2 control-label">Address: </label>
          <div className="col-sm-10">
            <input
              type="text"
              name="address"
              ref={node => addressInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <div className="col-sm-offset-2 col-sm-10">
            <input type="submit" className="btn btn-primary"/>
          </div>
        </div>
      </form>
    );
};

export default CustomerForm;
