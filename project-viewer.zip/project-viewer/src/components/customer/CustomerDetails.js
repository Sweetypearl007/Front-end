import React from 'react';

const CustomerDetails = (customer) => {
    return (
      <div className="media">
        <div className="media-left">
          <a href="/">
            <img className="media-object" src="http://placehold.it/200x280" alt="Placehold" />
          </a>
        </div>
        <div className="media-body">
          <h4 className="media-heading">{customer.title}</h4>
          <ul>
            <li><stron>Name: </stron> {customer.name}</li>
            <li><stron>Contact: </stron> {customer.contact}</li>
            <li><stron>Email: </stron> {customer.email}</li>
            <li><stron>Address: </stron> {customer.address}</li>
            <br/>
          </ul>
        </div>
      </div>
    );
};


export default CustomerDetails;
