import React from 'react';

const ProjectForm = (props) => {
    let nameInput, dateInput, descriptionInput = null;
    return (
      <form onSubmit={e => {
            e.preventDefault();
            var input = {
              name: nameInput.value,
              date: dateInput.value,
              description: descriptionInput.value,
              id: ''
            };
            props.submitProject(input);
            e.target.reset();
          }}
            className="form-horizontal"
      >
        <div className="input-group">
          <label className="col-sm-2 control-label">Project Name: </label>
          <div className="col-sm-10">
            <input
              placeholder="Project name"
              type="text"
              name="name"
              ref={node => nameInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <label className="col-sm-2 control-label">Date: </label>
          <div className="col-sm-10">
            <input
              placeholder="dd/mm/yyyy"
              type="text"
              name="date"
              ref={node => dateInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <label className="col-sm-2 control-label">Description: </label>
          <div className="col-sm-10">
            <input
              placeholder="Project description"
              type="text"
              name="description"
              ref={node => descriptionInput = node}
              className="form-control" />
          </div>
        </div>
        <br/>
        <div className="input-group">
          <div className="col-sm-offset-2 col-sm-10">
            <input type="submit" className="btn btn-primary"/>
          </div>
        </div>
      </form>
    );
};

export default ProjectForm;
