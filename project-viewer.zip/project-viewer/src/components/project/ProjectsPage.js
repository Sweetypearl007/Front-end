import React from 'react';
import { connect } from 'react-redux';
import ProjectForm from './ProjectForm';
import { Link } from 'react-router';
import * as projectActions from '../../actions/projectActions';

class Project extends React.Component{
  submitProject(input){
    this.props.createProject(input);
  }

  componentWillMount() {
    this.props.fetchProjects()
  }

  render(){
    return(
      <div className="row">
        <div className="col-md-6">
          <h3>Projects</h3>
          <table className="table">
            <thead>
              <tr><th>Projects and their details</th></tr>
            </thead>
            <tbody>
            {this.props.projects.map((b, i) => {
              return(
                <tr key={i}>
                  <td>{b.name}</td>
                  <td>{b.date}</td>
                  <td>{b.description}</td>
                  <td><Link to={`/projects/${b.id}`}>View</Link></td>
                </tr>
              )
            })}
            </tbody>
          </table>
        </div>
        <div className="col-md-6">
          <h3>New Project</h3>
         <ProjectForm submitProject={this.submitProject.bind(this)} />
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    projects: state.projects
  }
};

const mapDispatchToProps = (dispatch) => {
  return {
    createProject: project => dispatch(projectActions.createProject(project)),
    fetchProjects: () => dispatch(projectActions.fetchProjects())
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Project);
