import React from 'react';
import {connect} from 'react-redux';
import ProjectDetails from './ProjectDetails'
import * as projectActions from '../../actions/projectActions';


class ProjectDetailsPage extends React.Component {
    componentWillMount(){
        console.log('comp mounted')
        this.props.fetchProjectById(this.props.params.proj_id);
        console.log('will mount', this.props.project)
    }

    render() {
        console.log({props:this.props, state:this.state})
        return (
            <div>
                <h1>Project Details Page</h1>
                <ProjectDetails project={this.props.project}/>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    console.log('state mapping:', state)
    return {
      project: state.project
    };
};

const mapDispatchToProps = (dispatch) => {
    console.log('map dispatch')
    return {
      fetchProjectById: projectId => dispatch(projectActions.fetchProjectById(projectId)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ProjectDetailsPage);
