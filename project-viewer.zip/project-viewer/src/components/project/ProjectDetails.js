import React from 'react';
import {Link} from 'react-router'

const ProjectDetails = (_project) => {
  console.log('project details comp',{project:_project})
  const project = _project.project
  return (
    <div className="media">
      <div className="media-body">
        <h4 className="media-heading">Project Details</h4>
        <ul>
          <li><strong>Name: </strong> {project.name}</li>
          <li><strong>Date: </strong> {project.date}</li>
          <li><strong>Description: </strong> {project.description}</li>
          <br/>
        </ul>
        <Link to={`/projects/${project.id}/customers`}>View customers</Link>
      </div>
    </div>
  );
}

export default ProjectDetails;
