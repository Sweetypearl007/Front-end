import React  from 'react';
import {Route} from 'react-router';
import {Switch} from 'react-router-dom'
import HomePage from './components/common/HomePage'
import ProjectsPage from './components/project/ProjectsPage'
import LoginPage from './components/common/LoginPage';
import SignUpPage from './components/common/SignUpPage';
import ProjectDetailsPage from './components/project/ProjectDetailsPage';
import CustomerPage from './components/customer/CustomersPage';
import CustomerDetailsPage from './components/customer/CustomersPage';

export default (
  <Switch>
    <Route exact strict path="/projects/:proj_id/customers/:cust_id" component={CustomerPage}></Route>
    <Route exact strict path="/projects/:proj_id/customers" component={CustomerDetailsPage}></Route>
    <Route exact strict path="/projects/:proj_id" component={ProjectDetailsPage}></Route>
    <Route exact strict path="/projects" component={ProjectsPage}></Route>
    <Route exact strict path='/register' component={SignUpPage}></Route>
    <Route exact strict path="/login" component={LoginPage}></Route>
    <Route exact strict path="/" component={HomePage}></Route>
  </Switch>
)